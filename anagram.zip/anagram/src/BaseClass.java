import java.util.Scanner;

import static java.lang.System.*;

public class BaseClass
{
    public static void main(String arr[])
    {
        MethodContainer baseClass=new MethodContainer();
        Scanner scanner=new Scanner(System.in);
        while (true)
        {
            System.out.println("1 - Load cash \n 2 - Show customer details \n 3 - ATM functionalities");
            System.out.println("Enter the number respective to the action you want to perform or type \"0\" to exit : ");
            int Choise =scanner.nextInt();
            switch (Choise)
            {
                case 0:
                    System.out.println("--*--Thank you--*--");
                    System.exit(0);
                case 1:
                    System.out.println("Load cash page");
                    System.out.println("Enter the number of 2000 Rs : ");
                    int TwoThousand=scanner.nextInt();
                    System.out.println("Enter the number of 500 Rs : ");
                    int FiveHundred=scanner.nextInt();
                    System.out.println("Enter the number of 100 Rs : ");
                    int Hundred=scanner.nextInt();
                    baseClass.currencyDenomination(TwoThousand,FiveHundred,Hundred);
                    System.out.println("-*-Money successfully deposited-*-");
                    break;
                case 2:
                    System.out.println("Welcome to Customer detail page");
                    baseClass.showCurrency();
                    break;
                case 3:
                    System.out.println("ATM Functionalities");
                    System.out.println("Enter the account number : ");
                    String AccountNumber=scanner.next();
                    System.out.println("Enter the account password : ");
                    String PassWord=scanner.next();
                    if(baseClass.loginFunction(AccountNumber,PassWord))
                    {

                        System.out.println("---Logged in successfully---");
                        while (true)
                        {
                            out.println("-*-ATM Functionality Menu-*-");
                            System.out.println("1. Check Balance \n2. Withdraw Money \n3. Transfer Money \n4. Check ATM Balance");
                            System.out.println("Enter the number respective to the action you want to perform or type \"0\" to exit : ");
                            int Option=scanner.nextInt();
                            switch (Option) {
                                case 0 -> {
                                    System.out.println("Exited");
                                }
                                case 1 ->
                                {
                                    baseClass.checkBalance(MethodContainer.key);
                                }
                                case 2 ->
                                {
                                    out.println("This functionality is not available now");
                                    // not working
                                }
                                case 3 ->
                                {
                                    out.println("Enter the account number : ");
                                    String Acc_Number=scanner.next();
                                    out.println("Money you want to send : ");
                                    String Transation_Amount=scanner.next();
                                    if(Integer.parseInt(Transation_Amount)>=1000 || Integer.parseInt(Transation_Amount)<=10000)
                                    {
                                        if(baseClass.transactionCheck(Acc_Number,Transation_Amount))
                                        {
                                            baseClass.transferAmount(Transation_Amount);
                                            out.println("Transaction successful");
                                        }
                                        else
                                        {
                                            out.println("Given account number is wrong or balance is insufficient");
                                        }
                                    }
                                    else
                                    {
                                        out.println("You can only send money min 1000 and max 10000");
                                    }
                                }
                                case 4 ->
                                {
                                    baseClass.checkATMBalance();
                                }
                            }
                        }
                    }
                    else
                    {
                        System.out.println("Enter correct account number ");
                    }
                    break;
                default:
                    out.println("--Enter the correct Choice between 1 to 3--");
            }
        }

    }
}
