public class MethodContainer extends BaseClass {
    public static int i,key,key1;
    public static String[][] UserData = {
            {"101", "Suresh", "2343", "25234"},
            {"102", "Ganesh", "5432", "34123"},
            {"103", "Magesh", "7854", "26100"},
            {"104", "Naresh", "2345", "80000"},
            {"105", "Harish", "1907", "103400"}
    };
    public static int[][] Money = {
            {2000, 0, 0},
            {500, 0, 0},
            {100, 0, 0 }
    };
    public Boolean loginFunction(String AccNum, String Password) {
        for (i = 0; i < 5; i++) {
            if (UserData[i][0].equals(AccNum)) {
                if (UserData[i][2].equals(Password)) {
                    System.out.println("Logged in successfully as " + UserData[i][1]);
                    key=i;
                    return true;
                }
                else
                {
                    System.out.println("Enter the correct password");
                    return false;
                }
            }
        }
        System.out.println("***Enter correct account number***");
        return false;
    }
    public void currencyDenomination(int TwoThousand,int FiveHundred,int Hundred)
    {
        Money[0][1]=Money[0][1]+TwoThousand;
        Money[1][1]=Money[1][1]+FiveHundred;
        Money[2][1]=Money[2][1]+Hundred;
        Money[0][2]=Money[0][2]+2000*TwoThousand;
        Money[1][2]=Money[1][2]+500*FiveHundred;
        Money[2][2]=Money[2][2]+100*Hundred;
    }
    public void showCurrency()
    {
        for (i=0;i<5;i++)
        {
            for (int j=0;j<4;j++)
            {
                System.out.print(UserData[i][j]+"  ");
            }
            System.out.println();
        }
    }
    public void checkBalance(int location)
    {
        System.out.println("Mr."+UserData[location][1]+" your account balance is : "+UserData[location][3]);
    }
    public void transferAmount(String Amount)
    {

        int Balance=Integer.parseInt(UserData[key][3])-Integer.parseInt(Amount);
        int TotalBalance=Integer.parseInt(UserData[key1][3])-Integer.parseInt(Amount);
        UserData[key][3]=Integer.toString(Balance);
        UserData[key1][3]=Integer.toString(TotalBalance);
    }
    public Boolean transactionCheck(String Account_Number, String Amount)
    {
        boolean Acc_Num_flag=false;
        boolean Amount_flag=false;
        for(i=0;i<5;i++)
        {
            if(UserData[i][0].equals(Account_Number))
            {
                Acc_Num_flag=true;
                key1=i;
            }
        }
        if(Integer.parseInt(Amount) <= Integer.parseInt(UserData[key][3]))
        {
            Amount_flag=true;
        }
        return Acc_Num_flag == Amount_flag;
    }
    public void checkATMBalance()
    {
        int sum=Money[0][2]+Money[1][2]+Money[2][2];
        System.out.println("Total amount in ATM machine : "+sum);
    }
}
